# LoggerX
## Usage
```
pip install loggerx
```